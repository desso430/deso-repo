
public class Decrypt 
{

	 char[][] key ={{'Q','W','E','R','T'},
                    {'M','Y','U','I','O'},
                    {'P','A','S','D','F'},
                    {'G','H','J','K','L'},
                    {'X','C','V','B','N'}};

     final int N = 5;
     final int arrayLimit = N-1;
	 final int arrayStart = 0;
         
     void caseOneTwoThree(StringBuilder encrypted,char a,char b) // checks all other cases 1,2,3
    	throws IndexOutOfBoundsException  {
	    	int rowA = arrayStart, rowB = arrayStart;
	    	int columnA = arrayStart, columnB = arrayStart;
	    	
	     	if(a == 'Z') // if the letter a is 'Z'
	    	{
	    		encrypted.append("Z");
	    		encrypted.append(b);
	    	}
	    	if(b == 'Z') /// if the letter b is 'Z'
	    	{
	    		encrypted.append(a);
	    		encrypted.append("Z");
	    	}
	    	if(a != 'Z' && b != 'Z')
	    	{
	    	  for(int i = 0;i<N;i++)
	            for(int j = 0;j<N;j++)
	            {
	              if(key[i][j]== a)
	              {
	            	  rowA = i;   // save row index 
	            	  columnA = j;   // save column index
	              }
	              if(key[i][j]== b)
	              {
	            	  rowB = i;   // save row index
	            	  columnB = j;   // save column index
	              }
	            }
	    	  if(columnA == columnB) // case 3
	    	   {
	    		if(rowA == arrayStart)
	    			encrypted.append(key[arrayLimit][columnA]);
	    		else
	    			encrypted.append(key[rowA-1][columnA]);
	    	    if(rowB == arrayStart)
	    	    	encrypted.append(key[arrayLimit][columnB]);
	        	else
	        		encrypted.append(key[rowB-1][columnB]);
	    	   }
	    	  if(rowA ==  rowB)  // case 2
	     	   {
	     		if(columnA == arrayLimit)
	     			encrypted.append( key[ rowA][arrayStart]);
	     		else
	     			encrypted.append(key[ rowA][columnA+1]);
	     	    if(columnB == arrayLimit)
	     	    	encrypted.append(key[ rowB][arrayStart]);
	         	else
	         		encrypted.append(key[ rowB][columnB+1]);
	     	   }
	    	  if((rowA != rowB)&&(columnA != columnB))  // case 1
	    	  {
	    		encrypted.append(key[rowA][columnB]); 
	    		encrypted.append(key[rowB][columnA]);		
	    	  }
	    	}
	    }
  
     void caseFour(StringBuilder encrypted,char a)  // if a == b
       throws IndexOutOfBoundsException{
    	 if(a == 'Z')    // if the letters a and b are 'Z'
	    	encrypted.append("ZZ");
    	 else
    	 {
    		 for(int i = 0;i<N;i++)
               for(int j = 0;j<N;j++)
                 if(key[i][j]==a)
        	      {
                     if(i == arrayLimit)
                     {
            	       encrypted.append(key[arrayStart][j]);
            	       encrypted.append(key[arrayStart][j]);
                     }
        	         else
        	         {
        	    	   encrypted.append(key[i+1][j]);
        	    	   encrypted.append(key[i+1][j]);
        	         }
        	     }
    	 }
        
     } 
}
