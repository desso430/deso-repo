import java.util.InputMismatchException;
import java.util.Scanner;

public class Cipher 
{

	public static void main(String[] args) 
	{
		Scanner  input = new Scanner(System.in);		
		System.out.println("Please choose 1 or 2: ");
		System.out.printf("\n 1. Encrypt text! \n 2. Decrypt text! \n\n Choice:"); // Customer Menu
		int choice = 0;
		while(true)
		{
			try
			{
				 choice = input.nextInt();
		         if(choice != 1 && choice != 2) // if choice is different from 1 or 2
		         {						     
	                 System.out.print(" You have to insert 1 or 2: ");
	                 System.out.printf("\n 1. Encrypt text! \n 2. Decrypt text! \n\n Choice:");
	             }
		         else
                   break;
			}
			catch(InputMismatchException e) // invalid data
			{
				System.out.println("You entered invalid data!");
				break;
			}
		}
        if(choice == 1)
        {
        	System.out.println("Enter text: ");
		String check = input.next();
		String str= check.toUpperCase(); // make all letters uppercase
		StringBuilder in = new StringBuilder(str);
        if(in.length()%2 == 1)
          in.append("Z"); // make length of the string even number
         encrypt(in); // calling method to encrypt text
        }	   
        if(choice ==2)
        {
        	System.out.println("Enter text: ");
    		String check = input.next();
    		String str= check.toUpperCase(); // make all letters uppercase
    		StringBuilder in = new StringBuilder(str);
            if(in.length()%2 == 1)
              in.append("Z"); // make length of the string even number
             decrypt(in); // calling method to decrypt text
        }	   
	}
	static void encrypt( StringBuilder in) // encrypt text
	{
		try {
			   Encrypt text = new Encrypt();
		       StringBuilder encryptedText = new  StringBuilder(); // array for encrypted text
               char a, b;

           for(int index = 0;index <in.length();index += 2)
             {
                   a = in.charAt(index); 
                   b = in.charAt(index+1);

                 if(a == b) // if letters a and b are equal
                   text.caseFour(encryptedText, a);
                 else
                   text.caseOneTwoThree(encryptedText, a, b); // checks all other cases 1,2,3
             } 
           System.out.println(" Encrypted text is: " + encryptedText);
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println(" There was an unexpected error!");
		}
		
	  }
    
	static void decrypt(StringBuilder in)  // decrypt text
	{
		try {
		       Decrypt text = new Decrypt();
		       StringBuilder decryptedText = new  StringBuilder(); // array for decrypted text
               char a, b;

           for(int index = 0;index <in.length();index += 2)
             {
                   a = in.charAt(index);
                   b = in.charAt(index+1);
                   
                if(a == b)    // if letters a and b are equal
                 text.caseFour(decryptedText, a);
                else
       	         text.caseOneTwoThree(decryptedText, a, b); // checks all other cases 1,2,3

             } 
           if(decryptedText.charAt(decryptedText.length()-1) == 'Z')
        	   decryptedText.deleteCharAt(decryptedText.length()-1);  // if the last letter is 'Z', it remove it!
           System.out.println(" Decrypted text is: " + decryptedText);
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println(" There was an expected error!");
		}
		
	}
}
