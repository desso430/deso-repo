
public class Computer 
{
	int year;
	float price;
	boolean isNotebook;
	long hardDiskMemory;
	long freeMemory;
	String operationSystem;
	String producer;
	
	 void changeOperationSystem(String newOperationSystem)
	 {
		 if(newOperationSystem != null)
		   operationSystem = newOperationSystem;	 
	 }
	 
	 void useMemory(double memory)
	 {
		 if(memory > 0 && memory < freeMemory)
			freeMemory -= memory;
		 else
			System.out.println(" Not enough free memory! ");
	 }
}
