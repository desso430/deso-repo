import java.util.Scanner;

public class ComputerDemo 
{
	public static void main(String[] args)
	{
		Scanner  input = new Scanner(System.in);	
		
		Computer acer = new Computer();
		Computer sony = new Computer();
		
		System.out.printf("Enter info for first computer: \n");
		System.out.print("Enter year: ");
		acer.year = input.nextInt();
		System.out.print("Enter price: ");
		acer.price = input.nextFloat();
		System.out.print("Is this computer a notebook(true/false): ");
		acer.isNotebook = input.nextBoolean();
		System.out.print("Enter size of hard disk: ");
		acer.hardDiskMemory = input.nextLong();
		System.out.print("Enter free memory: ");
		acer.freeMemory = input.nextLong();
		System.out.print("Enter operation system of this computer: ");
		acer.operationSystem = input.next();
		
		System.out.printf("\nEnter info for second computer: \n");
		System.out.print("Enter year: ");
		sony.year = input.nextInt();
		System.out.print("Enter price: ");
		sony.price = input.nextFloat();
		System.out.print("Is this computer a notebook(true/false): ");
		sony.isNotebook = input.nextBoolean();
		System.out.print("Enter size of hard disk: ");
		sony.hardDiskMemory = input.nextLong();
		System.out.print("Enter free memory: ");
		sony.freeMemory = input.nextLong();
		System.out.print("Enter operation system of this computer: ");
	    sony.operationSystem = input.next();
		
		System.out.printf(" Change used memory for first cumputer: \n");
		int newFreeMemory = input.nextInt();
		acer.useMemory( newFreeMemory);
		System.out.printf(" Change operation system for second computer: \n");
		String newOperationSystem = input.next();
		sony.changeOperationSystem(newOperationSystem);
		
		System.out.printf("\n First computer: \n");
		System.out.printf(" 1.Year: %d \n 2.Price: %.2f \n 3.Notebook: %b \n 4.Hard disk memory: %d \n 5.Free memory: %d \n 6.Operation system: %s",acer.year,acer.price,acer.isNotebook,acer.hardDiskMemory,acer.freeMemory,acer.operationSystem);
		
		System.out.printf("\n\n Second computer: \n");
		System.out.printf(" 1.Year: %d \n 2.Price: %.2f \n 3.Notebook: %b \n 4.Hard disk memory: %d \n 5.Free memory: %d \n 6.Operation system: %s",sony.year,sony.price,sony.isNotebook,sony.hardDiskMemory,sony.freeMemory,sony.operationSystem);
	}

}
