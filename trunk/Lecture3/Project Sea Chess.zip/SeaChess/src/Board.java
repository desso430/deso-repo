
public class Board
{
	final int N=3;
    char[][] chess = new char[N][N];

  void  puts(int row,int col, char symbol)  // Puts symbol on given row and column
  {
	 if( chess[row-1][col-1] == '*')
		 chess[row-1][col-1] = symbol;
	 else
	 {
	    System.out.println(" This position is not free!");
	    return;
	 }	
   }
  void setDefaultValues()
  {
	  for(int i =0;i<N;i++)
	    	for(int j =0;j<N;j++)
	    		chess[i][j] = '*';
  }
    boolean End() // Game Over
	{
		int count = 0;
		boolean check = false;
		 for(int i = 0; i<3;i++)
		   {
			  for(int j = 0;j<3;j++)
			  { 
				  if(chess[i][j]!= '*')
					 count++;
			  }
		   }
		 if(count==9)
		    return check = true;
		 else
			return check = false;
	}
  
  boolean checkRow(char symbol)// check all rows
   {
		 int count = 0;
	     boolean flag = false;
	     
		    for(int i = 0; i<N;i++)
		    {
			 for(int j = 0;j<N;j++)
				{
			     if(chess[i][j] == symbol)
					 count++;
				}
		     if(count==3)
		    	return flag= true;
		     count = 0;
		    }
		    
	return flag;
   }
  boolean checkColumn(char symbol)
  {
		 int count = 0;
	     boolean flag = false;
         
		 // check all rows
		    for(int j = 0; j<N;j++)
		    {
			 for(int i = 0;i<N;i++)
				{
			     if(chess[i][j] == symbol)
					 count++;
				}
		     if(count==3)
		    	return flag= true;
		     count = 0;
		    }
	
	return flag;
  }
  
   boolean checkDiagonals(char symbol)
    { 
	   boolean flag = false;
	   int count = 0;
	  
	  for(int i = 0,j = 0;i<N;i++) // check main diagonal 
		{			
		  if(chess[i][j] == symbol)
			count++;
			j++;
		}
	  if(count == 3)
		  return flag = true;
				
	   count = 0;   
	  for(int i = 0,j = 2;i<N;i++) // check second diagonal 
		{
		 if(chess[i][j] == symbol)
	        count++;		  
			j--;	
		}
	  if(count == 3)
		  return flag = true;
	  
	  return flag;
  }
  void printChess()
  {
     for(int i = 0; i<N;i++)
	   {
		  for(int j = 0;j<N;j++)
			System.out.print(" "+chess[i][j]);
		System.out.printf("\n");
	   }
     return;
  }

	
}
