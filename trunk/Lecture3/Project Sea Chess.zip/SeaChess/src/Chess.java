import java.util.Scanner;

public class Chess {

	public static void main(String[] args) 
	{
      Scanner input = new Scanner(System.in);	
		
		Board seaChess = new Board();
		int row = 0, col = 0,turn = 0;
		seaChess.setDefaultValues();
		char symbol;
		
		  System.out.print("Enter name for first player: ");
			String player1 = input.nextLine();
			System.out.print("Enter name for second player: ");
			String player2 = input.nextLine();
		
		do {
			if(turn%2 == 0)
			{
			  if(seaChess.End() == true)
				{
				    seaChess.printChess();
					System.out.println(" Game Over!!! ");
					break;
				}
			 if((seaChess.checkRow('0') != true)&&(seaChess.checkColumn('0') != true)&&(seaChess.checkDiagonals('0') != true))
				 {
				   System.out.println("\n" + player1 + " enter row and column!");
				   seaChess.printChess();
				   System.out.print("\n row: ");
			       row = input.nextInt();
			       System.out.print(" col: ");
			       col = input.nextInt();
			       if((row > 0 && row < 4)&&(col > 0 && col < 4))
			         seaChess.puts(row,col,'x');
			       else
			    	 System.out.println(" Choose one number from 1 to 3!");
				 }
			 else
			   {
				  seaChess.printChess();
				  System.out.println(" Winner is: " + player2);
				  break;
			   } 
			}
			else
			{
			   if(seaChess.End() == true)
				{
				    seaChess.printChess();
					System.out.println(" Game Over!!! ");
					break;
				}				
		     if((seaChess.checkRow('x') != true)&&(seaChess.checkColumn('x') != true)&&(seaChess.checkDiagonals('x') != true))
			  {
			      System.out.println("\n" + player2 + " enter row and column!");
			      seaChess.printChess();
				  System.out.print("\n row: ");
				  row = input.nextInt();
				  System.out.print(" col: ");
				  col = input.nextInt();
				  if((row > 0 && row < 4)&&(col > 0 && col < 4))
				    seaChess.puts(row,col,'0');
				  else
		        	System.out.println(" Choose one number from 1 to 3!");
			  }
			  else
			  {
				  seaChess.printChess();
				  System.out.println(" Winner is: " + player1);
				  break;
			  }
			}
			turn++;
		} while(true);	
	}
}
